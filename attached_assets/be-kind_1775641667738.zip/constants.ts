
import { Dish, Event, ShopProduct, LoyaltyReward, LoyaltyAction, LoyaltyStamp } from './types';

export const MENU_CATEGORIES = ['Tutti', 'Bowl', 'Burger', 'Veg', 'Dolci', 'Bevande'];
export const SHOP_CATEGORIES = ['Tutti', 'Accessori', 'Merchandise', 'Food', 'Home'];

export const DISHES: Dish[] = [
  {
    id: '1',
    name: 'Green Power Bowl',
    description: 'Quinoa tricolore, avocado, edamame, cavolo viola marinato, semi di zucca e dressing al tahina.',
    price: 14.50,
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=1000&auto=format&fit=crop',
    category: 'Bowl',
    isVegan: true,
    rating: 4.8,
    reviews: 120
  },
  {
    id: '2',
    name: 'Be Kind Burger',
    description: 'Burger plant-based fatto in casa, cipolla caramellata, lattuga croccante, pomodoro cuore di bue e salsa speciale.',
    price: 16.00,
    image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?q=80&w=1000&auto=format&fit=crop',
    category: 'Burger',
    isVegetarian: true,
    rating: 4.9,
    reviews: 85
  },
  {
    id: '3',
    name: 'Avocado Toast Royal',
    description: 'Pane ai cereali tostato, avocado smash, uovo in camicia, semi di chia e germogli.',
    price: 12.00,
    image: 'https://images.unsplash.com/photo-1587132137056-bfbf0166836e?q=80&w=1000&auto=format&fit=crop',
    category: 'Veg',
    isVegetarian: true,
    rating: 4.7,
    reviews: 210
  },
  {
    id: '4',
    name: 'Cheesecake ai Frutti di Bosco',
    description: 'Base croccante integrale, crema leggera allo yogurt e topping di frutti di bosco freschi.',
    price: 7.50,
    image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?q=80&w=1000&auto=format&fit=crop',
    category: 'Dolci',
    rating: 4.9,
    reviews: 95
  }
];

export const UPCOMING_EVENTS: Event[] = [
  {
    id: 'e1',
    title: 'Workshop Cucina Vegana',
    date: '15 Mar 2024',
    time: '18:00 - 21:00',
    location: 'Be Kind Lab, Via dei Fiori 12',
    images: [
        'https://images.unsplash.com/photo-1507048331197-7d4ac70811cf?q=80&w=1000&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1556910103-1c02745a30bf?q=80&w=1000&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1466637574441-749b8f19452f?q=80&w=1000&auto=format&fit=crop'
    ],
    price: 35.00,
    category: 'Cucina',
    description: 'Impara a cucinare piatti vegani deliziosi e bilanciati con il nostro Chef Marco. \n\nIl corso include:\n• Tutti gli ingredienti necessari\n• Un grembiule Be Kind in omaggio\n• La cena finale con i piatti preparati\n\nPerfetto sia per principianti che per appassionati che vogliono scoprire nuovi sapori.',
    totalSpots: 15,
    bookedSpots: 12
  },
  {
    id: 'e2',
    title: 'Yoga & Brunch Domenicale',
    date: '20 Mar 2024',
    time: '09:00 - 12:00',
    location: 'Giardino Be Kind',
    images: [
        'https://images.unsplash.com/photo-1544367563-12123d8965cd?q=80&w=1000&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?q=80&w=1000&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1496417263034-38ec4f0d6b21?q=80&w=1000&auto=format&fit=crop'
    ],
    price: 25.00,
    category: 'Benessere',
    description: 'Inizia la giornata con un\'ora di Vinyasa Yoga flow nel nostro giardino segreto, seguita da un ricco brunch a buffet con opzioni dolci e salate, succhi pressati a freddo e caffè specialty. Porta il tuo tappetino!',
    totalSpots: 30,
    bookedSpots: 10
  }
];

export const SHOP_PRODUCTS: ShopProduct[] = [
  {
    id: 's1',
    name: 'Be Kind Tote Bag',
    price: 15.00,
    image: 'https://images.unsplash.com/photo-1554564883-9b2d8479e34e?auto=format&fit=crop&q=80&w=1000',
    category: 'Accessori',
    description: 'Borsa in cotone organico 100%, perfetta per la spesa o per portare i tuoi libri preferiti.'
  },
  {
    id: 's2',
    name: 'Borraccia Termica',
    price: 22.00,
    image: 'https://images.unsplash.com/photo-1602143407151-11115cd4e69b?auto=format&fit=crop&q=80&w=1000',
    category: 'Merchandise',
    description: 'Mantiene le bevande calde per 12 ore e fredde per 24. Acciaio inossidabile.'
  },
  {
    id: 's3',
    name: 'Granola Fatta in Casa',
    price: 8.50,
    image: 'https://images.unsplash.com/photo-1517093757186-b4850c904944?auto=format&fit=crop&q=80&w=1000',
    category: 'Food',
    description: 'Mix croccante di avena, miele, noci e frutta secca. Senza zuccheri raffinati aggiunti.'
  },
  {
    id: 's4',
    name: 'Set Candele Soia',
    price: 18.00,
    image: 'https://images.unsplash.com/photo-1602825389660-3f43144fc139?auto=format&fit=crop&q=80&w=1000',
    category: 'Home',
    description: 'Candele artigianali in cera di soia con oli essenziali naturali.'
  }
];

export const LOYALTY_REWARDS: LoyaltyReward[] = [
  {
    id: 'r1',
    title: 'Caffè o Tè Bio',
    cost: 150,
    type: 'FOOD',
    image: 'https://images.unsplash.com/photo-1511920170033-f8396924c348?auto=format&fit=crop&q=80&w=500',
    description: 'Una bevanda calda a tua scelta per iniziare la giornata con gentilezza.'
  },
  {
    id: 'r2',
    title: 'Dessert del Giorno',
    cost: 300,
    type: 'FOOD',
    image: 'https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?auto=format&fit=crop&q=80&w=500',
    description: 'Dolcezza meritata. Scegli una fetta di torta dal nostro bancone.'
  },
  {
    id: 'r3',
    title: 'Be Kind Tote Bag',
    cost: 600,
    type: 'MERCH',
    image: 'https://images.unsplash.com/photo-1554564883-9b2d8479e34e?auto=format&fit=crop&q=80&w=500',
    description: 'Porta i tuoi acquisti in modo sostenibile con la nostra shopper iconica.'
  },
  {
    id: 'r4',
    title: 'Lezione Yoga Gratuita',
    cost: 1000,
    type: 'EXPERIENCE',
    image: 'https://images.unsplash.com/photo-1544367563-12123d8965cd?auto=format&fit=crop&q=80&w=500',
    description: 'Un\'ora di benessere per il corpo e la mente nel nostro giardino.'
  }
];

export const EARN_ACTIONS: LoyaltyAction[] = [
  {
    id: 'a1',
    title: 'Invita un amico',
    points: 100,
    stamps: 0,
    icon: 'Users',
    description: 'Porta un amico nella community Be Kind.'
  },
  {
    id: 'a2',
    title: 'Lascia una recensione',
    points: 50,
    stamps: 0,
    icon: 'Star',
    description: 'Raccontaci la tua esperienza sull\'app.'
  },
  {
    id: 'a3',
    title: 'Partecipa a un evento',
    points: 150,
    stamps: 1,
    icon: 'Calendar',
    description: 'Unisciti ai nostri workshop o eventi sociali.'
  },
  {
    id: 'a4',
    title: 'Condividi su Instagram',
    points: 30,
    stamps: 0,
    icon: 'Instagram',
    description: 'Taggaci nelle tue storie @bekind_app.'
  }
];

export const LOYALTY_STAMPS: LoyaltyStamp[] = [
  {
    id: 'st1',
    title: 'Recensione',
    icon: 'Star',
    description: 'La tua opinione conta!',
    actionRequired: 'Lascia una recensione a 5 stelle sull\'App Store o Google Play.'
  },
  {
    id: 'st2',
    title: 'Brunch Lover',
    icon: 'Coffee', // Represents Brunch/Pancake vibe
    description: 'Colazione da campioni.',
    actionRequired: 'Vieni a trovarci per il brunch della domenica e scansiona il QR code al tavolo.'
  },
  {
    id: 'st3',
    title: 'Globetrotter',
    icon: 'Plane',
    description: 'Viaggia con noi.',
    actionRequired: 'Partecipa a uno dei nostri viaggi organizzati "Be Kind Experience".'
  },
  {
    id: 'st4',
    title: 'Delivery',
    icon: 'Bike',
    description: 'Comodamente a casa.',
    actionRequired: 'Effettua almeno 3 ordini con consegna a domicilio.'
  },
  {
    id: 'st5',
    title: 'Yogi',
    icon: 'Flower', // Lotus/Yoga
    description: 'Namasté.',
    actionRequired: 'Partecipa a una lezione di Yoga nel nostro giardino.'
  },
  {
    id: 'st6',
    title: 'Shopping',
    icon: 'ShoppingBag',
    description: 'Stile sostenibile.',
    actionRequired: 'Acquista un prodotto dal nostro Shop online.'
  },
  {
    id: 'st7',
    title: 'Community',
    icon: 'Users',
    description: 'Più siamo, meglio è.',
    actionRequired: 'Invita 3 amici a scaricare l\'app Be Kind.'
  },
  {
    id: 'st8',
    title: 'Social Star',
    icon: 'Smartphone',
    description: 'Dillo a tutti!',
    actionRequired: 'Condividi una foto dei nostri piatti nelle tue storie Instagram.'
  }
];
