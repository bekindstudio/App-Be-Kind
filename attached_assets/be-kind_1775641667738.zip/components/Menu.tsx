import React, { useState } from 'react';
import { ChevronLeft, Filter } from 'lucide-react';
import { MENU_CATEGORIES, DISHES } from '../constants';
import { Dish } from '../types';

interface MenuProps {
  onBack: () => void;
  onDishSelect: (dish: Dish) => void;
}

export const Menu: React.FC<MenuProps> = ({ onBack, onDishSelect }) => {
  const [activeCategory, setActiveCategory] = useState('Tutti');

  const filteredDishes = DISHES.filter(d => 
    activeCategory === 'Tutti' || d.category === activeCategory
  );

  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans">
      {/* Header */}
      <div className="px-6 pt-12 pb-4 flex items-center justify-between bg-bekind-bg sticky top-0 z-10">
        <button onClick={onBack} className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft text-bekind-primary">
            <ChevronLeft size={24} />
        </button>
        <h2 className="text-xl font-serif font-bold text-bekind-text">Il Nostro Menù</h2>
        <button className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft text-bekind-text">
            <Filter size={20} />
        </button>
      </div>

      {/* Categories */}
      <div className="flex gap-3 overflow-x-auto no-scrollbar px-6 pb-4 pt-2">
        {MENU_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-5 py-2 rounded-full whitespace-nowrap text-sm font-bold transition-all ${
              activeCategory === cat 
                ? 'bg-bekind-primary text-white shadow-md' 
                : 'bg-white text-bekind-text border border-gray-100'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-6 pb-24">
        <div className="grid grid-cols-2 gap-4">
          {filteredDishes.map((dish) => (
            <div 
              key={dish.id} 
              className="bg-white rounded-2xl overflow-hidden shadow-soft cursor-pointer group"
              onClick={() => onDishSelect(dish)}
            >
              <div className="h-32 overflow-hidden relative">
                <img src={dish.image} alt={dish.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute bottom-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg">
                    <span className="text-xs font-bold text-bekind-primary">€{dish.price.toFixed(2)}</span>
                </div>
              </div>
              <div className="p-3">
                <h3 className="font-serif font-bold text-bekind-text text-sm leading-tight mb-1 line-clamp-2">{dish.name}</h3>
                <p className="text-[10px] text-bekind-secondary line-clamp-2">{dish.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};