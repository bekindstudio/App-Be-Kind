
import React from 'react';
import { User, Package, CreditCard, Settings, HelpCircle, LogOut, ChevronRight } from 'lucide-react';

interface ProfileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProfileMenu: React.FC<ProfileMenuProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const menuItems = [
    { icon: User, label: 'Il mio profilo', action: () => console.log('Profile clicked') },
    { icon: Package, label: 'I miei ordini', action: () => console.log('Orders clicked') },
    { icon: CreditCard, label: 'Metodi di pagamento', action: () => console.log('Payment clicked') },
    { icon: Settings, label: 'Impostazioni', action: () => console.log('Settings clicked') },
    { icon: HelpCircle, label: 'Aiuto & Supporto', action: () => console.log('Help clicked') },
  ];

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-40 bg-black/5 backdrop-blur-[1px]" onClick={onClose}></div>
      
      {/* Menu */}
      <div className="absolute top-24 right-6 z-50 w-72 bg-white rounded-3xl shadow-xl border border-gray-100 transform transition-all animate-in fade-in slide-in-from-top-4 origin-top-right overflow-hidden">
        <div className="p-5 border-b border-gray-50 bg-gradient-to-r from-[#FFFBF5] to-white">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-full bg-bekind-primary/10 flex items-center justify-center text-bekind-primary font-bold text-lg">
                 M
             </div>
             <div>
                <p className="font-bold text-bekind-text text-sm">Marco Rossi</p>
                <p className="text-xs text-bekind-secondary">Germoglio 🌿 (350 pt)</p>
             </div>
          </div>
        </div>
        
        <div className="py-2">
          {menuItems.map((item, idx) => (
            <button 
              key={idx} 
              onClick={() => {
                item.action();
                onClose();
              }}
              className="w-full flex items-center justify-between px-5 py-3.5 text-sm text-gray-600 hover:bg-bekind-bg hover:text-bekind-primary transition-colors group active:bg-bekind-bg/80"
            >
              <div className="flex items-center gap-3">
                  <item.icon size={18} className="text-gray-400 group-hover:text-bekind-accent transition-colors" />
                  <span className="font-medium">{item.label}</span>
              </div>
              <ChevronRight size={14} className="text-gray-300 group-hover:text-bekind-accent" />
            </button>
          ))}
        </div>
        
        <div className="border-t border-gray-50 py-2 bg-gray-50/50">
          <button 
            onClick={onClose}
            className="w-full flex items-center gap-3 px-5 py-3.5 text-sm text-red-500 hover:bg-red-50 transition-colors font-medium active:bg-red-100"
          >
            <LogOut size={18} />
            Esci
          </button>
        </div>
      </div>
    </>
  );
};
