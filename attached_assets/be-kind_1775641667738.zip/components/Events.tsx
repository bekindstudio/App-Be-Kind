
import React from 'react';
import { ChevronLeft, MapPin, Calendar, Clock, ArrowRight } from 'lucide-react';
import { UPCOMING_EVENTS } from '../constants';
import { Event } from '../types';

interface EventsProps {
  onBack: () => void;
  onSelectEvent: (event: Event) => void;
}

export const Events: React.FC<EventsProps> = ({ onBack, onSelectEvent }) => {
  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans">
       <div className="px-6 pt-12 pb-4 flex items-center justify-between bg-bekind-bg sticky top-0 z-10">
        <button onClick={onBack} className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft text-bekind-primary hover:bg-white/50 transition-colors">
            <ChevronLeft size={24} />
        </button>
        <h2 className="text-xl font-serif font-bold text-bekind-text">Eventi Be Kind</h2>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24 no-scrollbar">
         {UPCOMING_EVENTS.map(event => (
             <div 
                key={event.id} 
                onClick={() => onSelectEvent(event)}
                className="bg-white rounded-3xl overflow-hidden shadow-soft mb-6 group cursor-pointer active:scale-[0.98] transition-all"
             >
                 <div className="h-44 relative overflow-hidden">
                     <img src={event.images[0]} alt={event.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                     <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-lg shadow-sm">
                         <span className="text-xs font-bold text-bekind-primary uppercase">{event.category}</span>
                     </div>
                     <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4 pt-10">
                         <h3 className="font-serif font-bold text-xl text-white leading-tight">{event.title}</h3>
                     </div>
                 </div>
                 
                 <div className="p-5">
                     <div className="flex flex-col gap-3 mb-5">
                        <div className="flex items-center gap-3 text-gray-600 text-sm">
                            <Calendar size={18} className="text-bekind-accent" />
                            <span className="font-medium">{event.date}</span>
                            <span className="text-gray-300">|</span>
                            <Clock size={16} className="text-bekind-secondary" />
                            <span className="text-xs">{event.time}</span>
                        </div>
                        <div className="flex items-center gap-3 text-gray-600 text-sm">
                            <MapPin size={18} className="text-bekind-accent" />
                            <span className="font-medium truncate">{event.location}</span>
                        </div>
                     </div>

                     <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                         <div>
                             <span className="text-[10px] text-gray-400 uppercase font-bold">Prezzo</span>
                             <div className="font-bold text-bekind-primary text-lg">€{event.price.toFixed(2)}</div>
                         </div>
                         <button className="bg-bekind-bg text-bekind-primary font-bold px-4 py-2 rounded-xl text-sm flex items-center gap-2 group-hover:bg-bekind-primary group-hover:text-white transition-colors">
                             Dettagli <ArrowRight size={16} />
                         </button>
                     </div>
                 </div>
             </div>
         ))}
      </div>
    </div>
  );
};
