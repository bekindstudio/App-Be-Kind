import React from 'react';
import { ChevronLeft, Phone, MapPin, Clock, CheckCircle2, Circle } from 'lucide-react';

interface TrackingProps {
  onBack: () => void;
}

export const Tracking: React.FC<TrackingProps> = ({ onBack }) => {
  // Simulazione dello stato corrente (0-4)
  // 0: Ricevuto, 1: In preparazione, 2: Pronto, 3: In arrivo, 4: Consegnato
  const currentStep = 3; 

  const steps = [
    { title: "Ordine ricevuto", desc: "Il tuo ordine è stato preso in carico." },
    { title: "In preparazione", desc: "Stiamo preparando il tuo ordine con cura." },
    { title: "Ordine pronto", desc: "Il tuo ordine è pronto per la consegna." },
    { title: "Rider in arrivo", desc: "Il rider sta arrivando da te." },
    { title: "Consegnato", desc: "Buon appetito!" }
  ];

  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans relative">
      
      {/* Header Galleggiante */}
      <div className="absolute top-0 left-0 right-0 p-6 pt-12 z-30 flex justify-between items-center pointer-events-none">
         <button onClick={onBack} className="pointer-events-auto w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft text-bekind-primary">
            <ChevronLeft size={24} />
        </button>
      </div>

      {/* Mappa */}
      <div className="h-[45%] w-full bg-gray-200 relative">
        <img 
            src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=1000&auto=format&fit=crop" 
            alt="Mappa" 
            className="w-full h-full object-cover opacity-80" 
        />
        {/* Overlay Mappa */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/10 to-transparent pointer-events-none"></div>
        
        {/* Marker Rider Simulato */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
            <div className="bg-bekind-primary text-white px-4 py-2 rounded-full shadow-lg font-bold text-xs mb-2 whitespace-nowrap animate-bounce flex items-center gap-2">
                <Clock size={12} />
                <span>Arrivo previsto: 13:25</span>
            </div>
            <div className="w-4 h-4 bg-bekind-accent border-2 border-white rounded-full shadow-lg relative">
                 <div className="absolute w-8 h-8 bg-bekind-accent/30 rounded-full -top-2 -left-2 animate-ping"></div>
            </div>
        </div>

        {/* Messaggio Stato Mappa */}
        <div className="absolute bottom-10 left-6 right-6">
             <div className="bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-lg border border-white/50">
                 <div className="flex items-center gap-3">
                     <div className="bg-green-100 p-2 rounded-full text-green-700">
                         <MapPin size={20} />
                     </div>
                     <div>
                         <h4 className="font-bold text-bekind-text text-sm">Il rider è quasi arrivato</h4>
                         <p className="text-xs text-gray-500">Posizione aggiornata in tempo reale</p>
                     </div>
                 </div>
             </div>
        </div>
      </div>

      {/* Content Sheet */}
      <div className="flex-1 bg-bekind-bg rounded-t-[30px] -mt-6 relative z-20 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)] flex flex-col overflow-hidden">
        
        <div className="w-12 h-1 bg-gray-300/50 rounded-full mx-auto mt-3 mb-4"></div>

        <div className="px-6 flex-1 overflow-y-auto no-scrollbar pb-6">
            
            {/* Titolo Be Kind Style */}
            <div className="mb-8 text-center">
                <h2 className="font-serif font-bold text-2xl text-bekind-text mb-1">Il tuo ordine è in viaggio 🌱</h2>
                <p className="text-bekind-secondary text-sm">Stiamo arrivando con gentilezza e puntualità 💚</p>
            </div>

            {/* Info Rider */}
            <div className="bg-white p-4 rounded-2xl shadow-soft mb-8 flex items-center justify-between border border-bekind-secondary/10">
                <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-100 border-2 border-white shadow-sm">
                        <img src="https://images.unsplash.com/photo-1542596594-649edbc13630?auto=format&fit=crop&q=80&w=200" alt="Rider" className="w-full h-full object-cover" />
                    </div>
                    <div>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Il tuo rider</p>
                        <h3 className="font-bold text-bekind-text">Luca</h3>
                    </div>
                </div>
                <button className="bg-[#E9F5E9] text-bekind-primary p-3 rounded-full hover:bg-bekind-primary hover:text-white transition-colors">
                    <Phone size={20} />
                </button>
            </div>

            {/* Timeline Stati */}
            <div className="relative pl-2 space-y-8">
                {/* Linea verticale di sfondo */}
                <div className="absolute left-[15px] top-2 bottom-4 w-0.5 bg-gray-100"></div>

                {steps.map((step, index) => {
                    const isCompleted = index < currentStep;
                    const isCurrent = index === currentStep;
                    
                    return (
                        <div key={index} className="relative flex gap-4 z-10">
                            {/* Icona Stato */}
                            <div className="flex-shrink-0 mt-0.5">
                                {isCompleted ? (
                                    <div className="w-7 h-7 rounded-full bg-bekind-primary text-white flex items-center justify-center border-4 border-bekind-bg shadow-sm">
                                        <CheckCircle2 size={14} />
                                    </div>
                                ) : isCurrent ? (
                                    <div className="w-7 h-7 rounded-full bg-bekind-accent border-4 border-bekind-bg shadow-lg flex items-center justify-center animate-pulse">
                                         <div className="w-2 h-2 bg-white rounded-full"></div>
                                    </div>
                                ) : (
                                    <div className="w-7 h-7 rounded-full bg-gray-200 border-4 border-bekind-bg flex items-center justify-center">
                                        <Circle size={10} className="text-gray-400 fill-gray-400" />
                                    </div>
                                )}
                            </div>

                            {/* Testo Stato */}
                            <div className={`${isCurrent ? 'opacity-100' : 'opacity-60'} transition-opacity`}>
                                <h4 className={`text-sm font-bold ${isCurrent ? 'text-bekind-primary text-base' : 'text-bekind-text'}`}>
                                    {step.title}
                                </h4>
                                {isCurrent && (
                                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                                        {step.desc}
                                    </p>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>

        </div>
      </div>
    </div>
  );
};