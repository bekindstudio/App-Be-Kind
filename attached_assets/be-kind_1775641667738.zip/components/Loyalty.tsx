
import React, { useState } from 'react';
import { ChevronLeft, Star, Gift, History, Leaf, CheckCircle2, Lock, ArrowRight, Share2, Users, Calendar, Plane, Coffee, Bike, Flower2, ShoppingBag, Smartphone, X } from 'lucide-react';
import { LOYALTY_REWARDS, EARN_ACTIONS, LOYALTY_STAMPS } from '../constants';
import { LoyaltyStamp } from '../types';

interface LoyaltyProps {
  onBack: () => void;
}

export const Loyalty: React.FC<LoyaltyProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'CARD' | 'REWARDS' | 'EARN'>('CARD');
  const [selectedStamp, setSelectedStamp] = useState<LoyaltyStamp | null>(null);
  
  // Mock User State
  const userState = {
    points: 350,
    level: 'Germoglio', // Seme -> Germoglio -> Quercia
    nextLevelPoints: 500,
    earnedStamps: ['st1', 'st4', 'st6'], // IDs of earned stamps
    history: [
      { date: '12 Mar', action: 'Pranzo Bowl', points: +45 },
      { date: '10 Mar', action: 'Ordine Delivery', points: +32 },
      { date: '05 Mar', action: 'Bonus Benvenuto', points: +100 },
    ]
  };

  const progressPercent = (userState.points / userState.nextLevelPoints) * 100;

  // Icon Mapping
  const getIcon = (iconName: string, size: number = 20, className: string = '') => {
      switch (iconName) {
          case 'Star': return <Star size={size} className={className} />;
          case 'Coffee': return <Coffee size={size} className={className} />;
          case 'Plane': return <Plane size={size} className={className} />;
          case 'Bike': return <Bike size={size} className={className} />;
          case 'Flower': return <Flower2 size={size} className={className} />;
          case 'ShoppingBag': return <ShoppingBag size={size} className={className} />;
          case 'Users': return <Users size={size} className={className} />;
          case 'Smartphone': return <Smartphone size={size} className={className} />;
          default: return <Leaf size={size} className={className} />;
      }
  };

  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans relative">
      
      {/* Stamp Details Modal */}
      {selectedStamp && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl relative">
                  <button 
                    onClick={() => setSelectedStamp(null)}
                    className="absolute top-4 right-4 w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-200"
                  >
                      <X size={18} />
                  </button>

                  <div className="flex flex-col items-center text-center mt-2">
                      <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${
                          userState.earnedStamps.includes(selectedStamp.id)
                          ? 'bg-bekind-primary text-white shadow-lg'
                          : 'bg-gray-100 text-gray-400 border-2 border-dashed border-gray-300'
                      }`}>
                          {getIcon(selectedStamp.icon, 40)}
                      </div>
                      
                      <h3 className="font-serif font-bold text-2xl text-bekind-text mb-1">{selectedStamp.title}</h3>
                      <p className="text-bekind-accent font-bold text-sm mb-4 uppercase tracking-wider">
                          {userState.earnedStamps.includes(selectedStamp.id) ? 'Timbro Ottenuto!' : 'Da Sbloccare'}
                      </p>
                      
                      <div className="bg-[#FFFBF5] p-4 rounded-xl w-full text-left mb-6 border border-bekind-secondary/20">
                          <p className="text-gray-600 text-sm leading-relaxed">
                              {selectedStamp.actionRequired}
                          </p>
                      </div>

                      <button 
                        onClick={() => setSelectedStamp(null)}
                        className="w-full bg-bekind-primary text-white font-bold py-3 rounded-xl shadow-md"
                      >
                          Chiudi
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Header with Navigation */}
      <div className="px-6 pt-12 pb-4 flex items-center gap-4 bg-bekind-bg sticky top-0 z-20">
        <button onClick={onBack} className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft text-bekind-primary border border-gray-50">
            <ChevronLeft size={24} />
        </button>
        <h2 className="text-xl font-serif font-bold text-bekind-text">Be Kind Fidelity</h2>
      </div>

      {/* Tabs */}
      <div className="px-6 mb-6">
        <div className="flex bg-white p-1 rounded-2xl shadow-sm border border-gray-100">
            {['CARD', 'REWARDS', 'EARN'].map((tab) => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab as any)}
                    className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all ${
                        activeTab === tab 
                        ? 'bg-bekind-primary text-white shadow-md' 
                        : 'text-gray-400 hover:text-bekind-text'
                    }`}
                >
                    {tab === 'CARD' ? 'La tua Carta' : tab === 'REWARDS' ? 'Premi' : 'Guadagna'}
                </button>
            ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-6 pb-24">
        
        {/* VIEW: CARD (Overview) */}
        {activeTab === 'CARD' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                
                {/* Digital Card */}
                <div className="bg-gradient-to-br from-bekind-primary to-[#2C4A32] rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
                    
                    <div className="flex justify-between items-start mb-8 relative z-10">
                        <div>
                            <p className="text-white/70 text-xs font-bold uppercase tracking-wider mb-1">Livello Attuale</p>
                            <h3 className="font-serif text-2xl font-bold flex items-center gap-2">
                                {userState.level} 🌿
                            </h3>
                        </div>
                        <div className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-full">
                            <span className="font-bold text-sm">{userState.points} Punti</span>
                        </div>
                    </div>

                    <div className="relative z-10">
                        <div className="flex justify-between text-xs mb-2 opacity-80">
                            <span>Progressi livello</span>
                            <span>{userState.nextLevelPoints - userState.points} punti al prossimo</span>
                        </div>
                        <div className="h-2 bg-black/20 rounded-full overflow-hidden">
                            <div className="h-full bg-bekind-accent rounded-full transition-all duration-1000" style={{ width: `${progressPercent}%` }}></div>
                        </div>
                    </div>
                </div>

                {/* Stamp Collection Grid */}
                <div className="bg-white p-6 rounded-3xl shadow-soft border border-bekind-secondary/20">
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="font-serif font-bold text-lg text-bekind-text">La tua Collezione</h3>
                        <span className="text-xs bg-[#E9F5E9] text-bekind-primary px-2 py-1 rounded-lg font-bold">
                            {userState.earnedStamps.length}/{LOYALTY_STAMPS.length}
                        </span>
                    </div>
                    <p className="text-gray-500 text-xs mb-6">Colleziona tutti i timbri per diventare una "Quercia"!</p>
                    
                    <div className="grid grid-cols-4 gap-4 mb-2">
                        {LOYALTY_STAMPS.map((stamp) => {
                             const isEarned = userState.earnedStamps.includes(stamp.id);
                             return (
                                 <button 
                                    key={stamp.id}
                                    onClick={() => setSelectedStamp(stamp)}
                                    className={`aspect-square rounded-2xl flex items-center justify-center transition-all active:scale-95 ${
                                        isEarned 
                                        ? 'bg-bekind-primary text-white shadow-md' 
                                        : 'bg-gray-50 border border-dashed border-gray-300 text-gray-300 hover:bg-gray-100'
                                    }`}
                                 >
                                     {getIcon(stamp.icon, 20)}
                                 </button>
                             )
                        })}
                    </div>
                </div>

                {/* Mini History */}
                <div>
                    <h3 className="font-bold text-bekind-text mb-3 flex items-center gap-2">
                        <History size={16} /> Attività Recenti
                    </h3>
                    <div className="bg-white rounded-2xl shadow-soft overflow-hidden">
                        {userState.history.map((item, idx) => (
                            <div key={idx} className="flex justify-between items-center p-4 border-b border-gray-50 last:border-0">
                                <div>
                                    <p className="font-bold text-sm text-bekind-text">{item.action}</p>
                                    <p className="text-xs text-gray-400">{item.date}</p>
                                </div>
                                <span className="font-bold text-bekind-primary">+{item.points} pt</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        )}

        {/* VIEW: REWARDS */}
        {activeTab === 'REWARDS' && (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="bg-[#E9F5E9] p-4 rounded-2xl flex items-center gap-3 mb-2">
                    <Gift className="text-bekind-primary" size={24} />
                    <div>
                        <p className="text-xs text-bekind-secondary font-bold uppercase">Saldo Disponibile</p>
                        <p className="text-xl font-bold text-bekind-primary">{userState.points} Punti</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 gap-4">
                    {LOYALTY_REWARDS.map((reward) => {
                        const canAfford = userState.points >= reward.cost;
                        return (
                            <div key={reward.id} className={`bg-white p-4 rounded-2xl shadow-soft flex gap-4 ${!canAfford ? 'opacity-70' : ''}`}>
                                <div className="w-20 h-20 rounded-xl bg-gray-100 flex-shrink-0 overflow-hidden">
                                    <img src={reward.image} alt={reward.title} className="w-full h-full object-cover" />
                                </div>
                                <div className="flex-1 flex flex-col justify-between">
                                    <div>
                                        <div className="flex justify-between items-start">
                                            <h4 className="font-bold text-bekind-text text-sm mb-1">{reward.title}</h4>
                                            {canAfford ? <CheckCircle2 size={16} className="text-bekind-primary" /> : <Lock size={16} className="text-gray-300" />}
                                        </div>
                                        <p className="text-[10px] text-gray-500 line-clamp-2">{reward.description}</p>
                                    </div>
                                    <div className="flex justify-between items-end mt-2">
                                        <span className="font-bold text-bekind-accent text-sm">{reward.cost} pt</span>
                                        <button 
                                            disabled={!canAfford}
                                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                                                canAfford 
                                                ? 'bg-bekind-primary text-white hover:bg-opacity-90' 
                                                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                            }`}
                                        >
                                            Riscatta
                                        </button>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        )}

        {/* VIEW: EARN */}
        {activeTab === 'EARN' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="text-center mb-4">
                    <h3 className="font-serif font-bold text-xl text-bekind-text">Guadagna Punti</h3>
                    <p className="text-sm text-gray-500">Completa le azioni per salire di livello</p>
                </div>

                <div className="space-y-3">
                    {/* Hardcoded Dynamic Logic for visual list */}
                    {EARN_ACTIONS.map((action) => (
                        <div key={action.id} className="bg-white p-4 rounded-2xl shadow-soft flex items-center justify-between group active:scale-[0.98] transition-transform cursor-pointer">
                            <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full bg-[#FFFBF5] border border-bekind-secondary/20 flex items-center justify-center text-bekind-primary">
                                    {/* Icon Mapping Strategy */}
                                    {getIcon(action.icon, 20)}
                                </div>
                                <div>
                                    <h4 className="font-bold text-sm text-bekind-text">{action.title}</h4>
                                    <p className="text-[10px] text-gray-500 max-w-[180px]">{action.description}</p>
                                </div>
                            </div>
                            <div className="flex flex-col items-end">
                                <span className="font-bold text-bekind-accent">+{action.points} pt</span>
                                {action.stamps > 0 && (
                                    <span className="text-[10px] text-bekind-primary font-bold flex items-center gap-1">
                                        +{action.stamps} <Leaf size={8} />
                                    </span>
                                )}
                            </div>
                        </div>
                    ))}

                    {/* Standard Action */}
                    <div className="bg-gradient-to-r from-bekind-bg to-[#F0F7F0] p-4 rounded-2xl shadow-soft border border-bekind-primary/10 flex items-center justify-between">
                         <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-bekind-primary shadow-sm">
                                <Leaf size={20} />
                            </div>
                            <div>
                                <h4 className="font-bold text-sm text-bekind-text">Ad ogni acquisto</h4>
                                <p className="text-[10px] text-gray-500">Guadagna 1 punto per ogni €1 speso</p>
                            </div>
                        </div>
                        <ArrowRight size={16} className="text-bekind-secondary" />
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};
