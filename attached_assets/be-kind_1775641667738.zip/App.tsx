
import React, { useState } from 'react';
import { Onboarding } from './components/Onboarding';
import { Home } from './components/Home';
import { Details } from './components/Details';
import { Cart } from './components/Cart';
import { BottomNav } from './components/BottomNav';
import { Menu } from './components/Menu';
import { Reservation } from './components/Reservation';
import { Shop } from './components/Shop';
import { Tracking } from './components/Tracking';
import { Events } from './components/Events';
import { EventDetails } from './components/EventDetails';
import { Loyalty } from './components/Loyalty';
import { Checkout } from './components/Checkout';
import { Dish, ViewState, CartItem, ShopProduct, Event } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('ONBOARDING');
  const [selectedDish, setSelectedDish] = useState<Dish | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleStart = () => {
    setCurrentView('HOME');
  };

  const handleDishSelect = (dish: Dish) => {
    setSelectedDish(dish);
    setCurrentView('DISH_DETAILS');
  };

  const handleEventSelect = (event: Event) => {
    setSelectedEvent(event);
    setCurrentView('EVENT_DETAILS');
  };

  const handleBackToHome = () => {
    setSelectedDish(null);
    setSelectedEvent(null);
    setCurrentView('HOME');
  };

  const addToCart = (product: Dish | ShopProduct, size: string = 'Standard') => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          (item.id === product.id)
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1, size }]; 
    });
    setCurrentView('CART');
  };

  const handleEventBooking = (event: Event, quantity: number) => {
      // Changed to Add to Cart flow instead of direct checkout
      const ticketItem: CartItem = {
          id: event.id,
          name: `Ticket: ${event.title}`,
          price: event.price,
          image: event.images[0], // Use first image
          category: 'Eventi',
          quantity: quantity,
          size: 'Ingresso'
      };
      
      setCartItems(prev => {
          // Replace existing tickets for same event or add new
          const others = prev.filter(p => p.id !== event.id);
          return [...others, ticketItem];
      });
      
      setCurrentView('CART');
  };

  const updateQuantity = (id: string, delta: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = item.quantity + delta;
        return newQty > 0 ? { ...item, quantity: newQty } : item;
      }
      return item;
    }));
  };

  const removeItem = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  // Helper for Checkout Total
  const cartTotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0) + 2.50; // + Shipping

  const handlePaymentSuccess = () => {
      setCartItems([]); // Clear cart
      // Determine where to go based on what we bought. 
      // If it was an event, maybe go back to home or a specific "Tickets" page (Tracking works as a generic success for now)
      setCurrentView('TRACKING'); 
  };

  return (
    <div className="flex justify-center min-h-screen bg-[#E5E5E5] font-sans text-bekind-text">
      <div className="w-full max-w-md bg-bekind-bg h-screen overflow-hidden relative shadow-2xl">
        
        {/* Main Content Area */}
        <div className="h-full w-full">
          {currentView === 'ONBOARDING' && (
            <Onboarding onStart={handleStart} />
          )}

          {currentView === 'HOME' && (
            <Home 
                onNavigate={setCurrentView} 
                onDishSelect={handleDishSelect} 
            />
          )}

          {currentView === 'MENU' && (
            <Menu 
                onBack={handleBackToHome}
                onDishSelect={handleDishSelect}
            />
          )}

          {currentView === 'DISH_DETAILS' && selectedDish && (
            <Details 
              product={selectedDish} 
              onBack={() => setCurrentView('MENU')} // Go back to menu usually
              onAddToCart={addToCart}
            />
          )}

          {currentView === 'RESERVATION' && (
            <Reservation onBack={handleBackToHome} />
          )}

          {currentView === 'SHOP' && (
            <Shop 
                onBack={handleBackToHome} 
                onAddToCart={(p) => addToCart(p)}
            />
          )}

          {currentView === 'TRACKING' && (
            <Tracking onBack={handleBackToHome} />
          )}

          {currentView === 'EVENTS' && (
            <Events 
                onBack={handleBackToHome} 
                onSelectEvent={handleEventSelect}
            />
          )}

          {currentView === 'EVENT_DETAILS' && selectedEvent && (
            <EventDetails 
                event={selectedEvent}
                onBack={() => setCurrentView('EVENTS')}
                onBook={handleEventBooking}
            />
          )}

          {currentView === 'LOYALTY' && (
            <Loyalty onBack={handleBackToHome} />
          )}

          {currentView === 'CART' && (
            <Cart 
              cartItems={cartItems} 
              onBack={handleBackToHome}
              onUpdateQuantity={updateQuantity}
              onRemoveItem={removeItem}
              onCheckout={() => setCurrentView('CHECKOUT')}
            />
          )}

          {currentView === 'CHECKOUT' && (
              <Checkout 
                onBack={() => setCurrentView('CART')}
                onSuccess={handlePaymentSuccess}
                total={cartTotal}
                cartItems={cartItems} // Pass items to check for events
              />
          )}
        </div>

        {/* Navigation */}
        <BottomNav 
          currentView={currentView} 
          onNavigate={setCurrentView} 
          cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
        />
        
      </div>
    </div>
  );
};

export default App;
