import React, { useState } from 'react';
import { ChevronLeft, ShoppingBag, Heart, Share2, Info } from 'lucide-react';
import { Dish } from '../types';

interface DetailsProps {
  product: Dish; // Reusing product prop name but typing as Dish for minimal refactor
  onBack: () => void;
  onAddToCart: (product: any, size: string) => void;
}

export const Details: React.FC<DetailsProps> = ({ product, onBack, onAddToCart }) => {
  const [isFavorite, setIsFavorite] = useState(false);
  const [quantity, setQuantity] = useState(1);

  return (
    <div className="flex flex-col h-full bg-bekind-bg overflow-hidden relative font-sans">
      
      {/* Top Nav */}
      <div className="absolute top-0 left-0 right-0 z-30 px-6 pt-12 flex justify-between items-center pointer-events-none">
        <button onClick={onBack} className="pointer-events-auto w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center shadow-soft text-bekind-primary">
            <ChevronLeft size={24} />
        </button>
        <div className="flex gap-3 pointer-events-auto">
            <button onClick={() => setIsFavorite(!isFavorite)} className="w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center shadow-soft transition-colors">
                <Heart size={20} className={isFavorite ? "text-red-500 fill-red-500" : "text-bekind-primary"} />
            </button>
        </div>
      </div>

      {/* Image */}
      <div className="h-[45%] w-full relative">
         <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bekind-bg to-transparent"></div>
      </div>

      {/* Content Sheet */}
      <div className="flex-1 px-6 -mt-10 relative z-10 flex flex-col">
        <div className="mb-2 flex items-start justify-between">
            <div>
                 <span className="text-bekind-accent text-xs font-bold uppercase tracking-wider">{product.category}</span>
                 <h1 className="font-serif font-bold text-3xl text-bekind-text leading-tight">{product.name}</h1>
            </div>
            <div className="flex flex-col items-end">
                 <span className="font-serif font-bold text-2xl text-bekind-primary">€{product.price.toFixed(2)}</span>
            </div>
        </div>

        <div className="flex items-center gap-4 mb-6">
             <div className="flex items-center gap-1">
                <span className="text-yellow-500 text-sm">★</span>
                <span className="font-bold text-bekind-text text-sm">{product.rating}</span>
                <span className="text-bekind-secondary text-xs">({product.reviews})</span>
            </div>
            {product.isVegan && (
                <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2 py-0.5 rounded-full">VEGAN</span>
            )}
             {product.isVegetarian && !product.isVegan && (
                <span className="bg-green-50 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded-full">VEG</span>
            )}
        </div>

        <div className="mb-6 overflow-y-auto max-h-[150px] no-scrollbar">
            <h3 className="font-bold text-bekind-text mb-2">Descrizione</h3>
            <p className="text-gray-600 text-sm leading-relaxed">
                {product.description}
            </p>
        </div>
        
        {/* Ingredients/Allergens Mock */}
        <div className="mb-6 p-4 bg-white rounded-xl shadow-sm border border-bekind-secondary/20 flex gap-3 items-start">
            <Info size={16} className="text-bekind-primary mt-0.5" />
            <p className="text-xs text-gray-500">
                <span className="font-bold text-bekind-text">Allergeni:</span> Glutine, Soia, Sesamo.
            </p>
        </div>

      </div>

      {/* Bottom Action Bar */}
      <div className="bg-white border-t border-gray-100 px-6 py-4 pb-8 z-30 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]">
        <div className="flex items-center gap-4">
             {/* Quantity */}
             <div className="flex items-center gap-3 bg-bekind-bg px-3 py-2 rounded-xl">
                 <button onClick={() => quantity > 1 && setQuantity(q => q - 1)} className="text-bekind-primary font-bold text-lg px-2">-</button>
                 <span className="text-bekind-text font-bold">{quantity}</span>
                 <button onClick={() => setQuantity(q => q + 1)} className="text-bekind-primary font-bold text-lg px-2">+</button>
             </div>

            <button 
                onClick={() => onAddToCart(product, 'Standard')}
                className="flex-1 bg-bekind-primary text-white font-bold text-sm py-4 rounded-2xl shadow-lg hover:bg-opacity-90 transition-colors flex items-center justify-center gap-2 active:scale-95"
            >
                Aggiungi al Carrello — €{(product.price * quantity).toFixed(2)}
            </button>
        </div>
      </div>
    </div>
  );
};