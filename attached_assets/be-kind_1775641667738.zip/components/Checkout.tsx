
import React, { useState } from 'react';
import { ChevronLeft, CreditCard, Truck, MapPin, Check, Wallet, Lock, ShieldCheck, Users, Ticket } from 'lucide-react';
import { CartItem } from '../types';

interface CheckoutProps {
  onBack: () => void;
  onSuccess: () => void;
  total: number;
  cartItems?: CartItem[]; // Passed to check for events
}

export const Checkout: React.FC<CheckoutProps> = ({ onBack, onSuccess, total, cartItems = [] }) => {
  const hasEvents = cartItems.some(item => item.category === 'Eventi');
  
  const [step, setStep] = useState<'ATTENDEE_INFO' | 'SHIPPING_PAYMENT'>(hasEvents ? 'ATTENDEE_INFO' : 'SHIPPING_PAYMENT');
  const [paymentMethod, setPaymentMethod] = useState<'CARD' | 'PAYPAL'>('CARD');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    address: '',
    city: '',
    zip: '',
    phone: '',
    cardNumber: '',
    expiry: '',
    cvc: ''
  });

  // State for attendees: map cart item ID to array of names
  const [attendees, setAttendees] = useState<Record<string, {name: string, surname: string}[]>>(() => {
    const initial: Record<string, {name: string, surname: string}[]> = {};
    cartItems.filter(i => i.category === 'Eventi').forEach(item => {
        initial[item.id] = Array(item.quantity).fill({ name: '', surname: '' });
    });
    return initial;
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleAttendeeChange = (itemId: string, index: number, field: 'name' | 'surname', value: string) => {
      setAttendees(prev => {
          const newAttendees = [...prev[itemId]];
          newAttendees[index] = { ...newAttendees[index], [field]: value };
          return { ...prev, [itemId]: newAttendees };
      });
  };

  const isAttendeeStepValid = () => {
      // Check if all fields are filled
      return Object.keys(attendees).every(key => 
        attendees[key].every(p => p.name.trim() !== '' && p.surname.trim() !== '')
      );
  };

  const handlePay = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col h-full bg-bekind-bg items-center justify-center px-8 text-center font-sans">
        <div className="w-24 h-24 bg-[#E9F5E9] rounded-full flex items-center justify-center mb-6 shadow-soft animate-bounce">
            <ShieldCheck size={40} className="text-bekind-primary" />
        </div>
        <h2 className="text-3xl font-serif font-bold text-bekind-text mb-2">Acquisto Confermato!</h2>
        <p className="text-gray-600 mb-8 max-w-[250px] mx-auto leading-relaxed">
            Grazie per il tuo ordine. Riceverai un'email di conferma con i biglietti.
        </p>
        <button onClick={onSuccess} className="w-full bg-bekind-primary text-white font-bold py-4 px-8 rounded-2xl shadow-lg hover:bg-opacity-90 transition-all">
            Torna alla Home
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans">
      {/* Header */}
      <div className="px-6 pt-12 pb-4 flex items-center justify-between bg-bekind-bg sticky top-0 z-10">
        <button onClick={() => step === 'SHIPPING_PAYMENT' && hasEvents ? setStep('ATTENDEE_INFO') : onBack()} className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft text-bekind-primary border border-gray-50">
            <ChevronLeft size={24} />
        </button>
        <h2 className="text-xl font-serif font-bold text-bekind-text">Checkout</h2>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24 no-scrollbar">
        
        {/* Step: Attendee Info (Only for Events) */}
        {step === 'ATTENDEE_INFO' && (
            <div className="animate-in fade-in slide-in-from-right-8 duration-300">
                <div className="mb-6">
                    <div className="flex items-center gap-2 mb-4 text-bekind-primary">
                        <Users size={20} />
                        <span className="font-bold text-lg">Dati Partecipanti</span>
                    </div>
                    <p className="text-sm text-gray-500 mb-6">Inserisci i nominativi per ogni biglietto acquistato.</p>
                    
                    {cartItems.filter(i => i.category === 'Eventi').map(item => (
                        <div key={item.id} className="mb-8">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="w-10 h-10 rounded-lg bg-white overflow-hidden shadow-sm">
                                    <img src={item.image} className="w-full h-full object-cover" />
                                </div>
                                <h3 className="font-bold text-bekind-text text-sm">{item.name}</h3>
                            </div>
                            
                            <div className="space-y-4">
                                {attendees[item.id].map((attendee, index) => (
                                    <div key={index} className="bg-white p-4 rounded-2xl shadow-soft border border-gray-50">
                                        <div className="flex items-center gap-2 mb-3 text-bekind-accent font-bold text-xs uppercase tracking-wider">
                                            <Ticket size={14} /> Biglietto #{index + 1}
                                        </div>
                                        <div className="grid grid-cols-2 gap-3">
                                            <input 
                                                type="text" 
                                                placeholder="Nome"
                                                value={attendee.name}
                                                onChange={(e) => handleAttendeeChange(item.id, index, 'name', e.target.value)}
                                                className="w-full bg-[#F9F9F9] rounded-xl py-3 px-4 text-sm outline-none focus:ring-2 focus:ring-bekind-accent/20"
                                            />
                                            <input 
                                                type="text" 
                                                placeholder="Cognome"
                                                value={attendee.surname}
                                                onChange={(e) => handleAttendeeChange(item.id, index, 'surname', e.target.value)}
                                                className="w-full bg-[#F9F9F9] rounded-xl py-3 px-4 text-sm outline-none focus:ring-2 focus:ring-bekind-accent/20"
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        )}

        {/* Step: Shipping & Payment */}
        {step === 'SHIPPING_PAYMENT' && (
             <div className="animate-in fade-in slide-in-from-right-8 duration-300">
                <div className="mb-6">
                    <div className="flex items-center gap-2 mb-4 text-bekind-primary">
                        <Truck size={20} />
                        <span className="font-bold text-lg">Dati Fatturazione</span>
                    </div>
                    <div className="bg-white p-5 rounded-3xl shadow-soft space-y-3">
                        <div className="space-y-1">
                            <label className="text-xs font-bold text-gray-500 ml-1">Nome e Cognome</label>
                            <input 
                                type="text" 
                                name="name" 
                                placeholder="Mario Rossi"
                                value={formData.name}
                                onChange={handleInputChange}
                                className="w-full bg-[#F9F9F9] rounded-xl py-3 px-4 text-sm outline-none focus:ring-2 focus:ring-bekind-accent/20"
                            />
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs font-bold text-gray-500 ml-1">Indirizzo</label>
                            <div className="relative">
                                <MapPin size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                <input 
                                    type="text" 
                                    name="address" 
                                    placeholder="Via Roma, 123"
                                    value={formData.address}
                                    onChange={handleInputChange}
                                    className="w-full bg-[#F9F9F9] rounded-xl py-3 pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-bekind-accent/20"
                                />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <input 
                                type="text" 
                                name="city" 
                                placeholder="Milano" 
                                value={formData.city}
                                onChange={handleInputChange}
                                className="w-full bg-[#F9F9F9] rounded-xl py-3 px-4 text-sm outline-none focus:ring-2 focus:ring-bekind-accent/20"
                            />
                            <input 
                                type="text" 
                                name="zip" 
                                placeholder="20100" 
                                value={formData.zip}
                                onChange={handleInputChange}
                                className="w-full bg-[#F9F9F9] rounded-xl py-3 px-4 text-sm outline-none focus:ring-2 focus:ring-bekind-accent/20"
                            />
                        </div>
                    </div>
                </div>

                <div className="mb-6">
                    <div className="flex items-center gap-2 mb-4 text-bekind-primary">
                        <Wallet size={20} />
                        <span className="font-bold text-lg">Metodo di Pagamento</span>
                    </div>
                    
                    <div className="bg-white p-5 rounded-3xl shadow-soft">
                        <div className="flex p-1 bg-gray-50 rounded-xl mb-6">
                            <button 
                                onClick={() => setPaymentMethod('CARD')}
                                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${
                                    paymentMethod === 'CARD' ? 'bg-bekind-primary text-white shadow-md' : 'text-gray-400'
                                }`}
                            >
                                <CreditCard size={14} /> Carta
                            </button>
                            <button 
                                onClick={() => setPaymentMethod('PAYPAL')}
                                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${
                                    paymentMethod === 'PAYPAL' ? 'bg-[#003087] text-white shadow-md' : 'text-gray-400'
                                }`}
                            >
                                <span className="italic font-serif">Pay</span>Pal
                            </button>
                        </div>

                        {paymentMethod === 'CARD' ? (
                            <div className="space-y-4 animate-in fade-in">
                                <div className="bg-gradient-to-br from-bekind-primary to-bekind-text h-40 rounded-2xl p-5 text-white flex flex-col justify-between shadow-lg relative overflow-hidden">
                                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl transform translate-x-10 -translate-y-10"></div>
                                    <div className="flex justify-between items-start">
                                        <span className="font-serif italic text-white/50">Be Kind Pay</span>
                                        <CreditCard className="text-white/80" />
                                    </div>
                                    <div>
                                        <p className="font-mono text-lg tracking-widest mb-1">
                                            {formData.cardNumber || '•••• •••• •••• ••••'}
                                        </p>
                                        <div className="flex justify-between items-end">
                                            <span className="text-xs uppercase opacity-70">{formData.name || 'NOME TITOLARE'}</span>
                                            <span className="font-mono text-sm">{formData.expiry || 'MM/YY'}</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-3">
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-gray-500 ml-1">Numero Carta</label>
                                        <div className="relative">
                                            <CreditCard size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                            <input 
                                                type="text" 
                                                name="cardNumber"
                                                placeholder="0000 0000 0000 0000"
                                                maxLength={19}
                                                value={formData.cardNumber}
                                                onChange={handleInputChange}
                                                className="w-full bg-[#F9F9F9] rounded-xl py-3 pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-bekind-accent/20"
                                            />
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-2 gap-3">
                                        <div className="space-y-1">
                                            <label className="text-xs font-bold text-gray-500 ml-1">Scadenza</label>
                                            <input 
                                                type="text" 
                                                name="expiry"
                                                placeholder="MM/YY" 
                                                maxLength={5}
                                                value={formData.expiry}
                                                onChange={handleInputChange}
                                                className="w-full bg-[#F9F9F9] rounded-xl py-3 px-4 text-sm outline-none focus:ring-2 focus:ring-bekind-accent/20"
                                            />
                                        </div>
                                        <div className="space-y-1">
                                            <label className="text-xs font-bold text-gray-500 ml-1">CVC</label>
                                            <div className="relative">
                                                <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                                <input 
                                                    type="text" 
                                                    name="cvc"
                                                    placeholder="123" 
                                                    maxLength={3}
                                                    value={formData.cvc}
                                                    onChange={handleInputChange}
                                                    className="w-full bg-[#F9F9F9] rounded-xl py-3 pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-bekind-accent/20"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="text-center py-6 animate-in fade-in">
                                <p className="text-sm text-gray-500 mb-4">Verrai reindirizzato al sito di PayPal per completare il pagamento in sicurezza.</p>
                                <button className="bg-[#FFC439] text-[#003087] font-bold py-3 px-6 rounded-xl w-full shadow-sm hover:bg-[#F4BB30] transition-colors flex items-center justify-center gap-2">
                                    Paga con <span className="italic font-serif">PayPal</span>
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        )}

      </div>

      {/* Footer */}
      <div className="bg-white rounded-t-[30px] p-6 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.05)] z-20">
        <div className="flex justify-between items-center mb-4">
            <span className="text-gray-500 text-sm">Totale da pagare</span>
            <span className="font-serif font-bold text-2xl text-bekind-primary">€{total.toFixed(2)}</span>
        </div>
        
        {step === 'ATTENDEE_INFO' ? (
             <button 
                onClick={() => setStep('SHIPPING_PAYMENT')}
                disabled={!isAttendeeStepValid()}
                className="w-full bg-bekind-primary text-white font-bold py-4 rounded-2xl shadow-lg hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
                Continua
            </button>
        ) : (
             <button 
                onClick={handlePay}
                disabled={isProcessing}
                className="w-full bg-bekind-accent text-white font-bold py-4 rounded-2xl shadow-lg hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
                {isProcessing ? (
                    <>Processando...</>
                ) : (
                    <>
                        <Lock size={18} /> Paga Ora
                    </>
                )}
            </button>
        )}
      </div>
    </div>
  );
};
