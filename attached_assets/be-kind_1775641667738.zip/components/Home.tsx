
import React, { useEffect, useState } from 'react';
import { ShoppingBag, Calendar, Utensils, Bike, Bell, ArrowRight } from 'lucide-react';
import { UPCOMING_EVENTS } from '../constants';
import { Dish, ViewState } from '../types';
import { ProfileMenu } from './ProfileMenu';

interface HomeProps {
  onNavigate: (view: ViewState) => void;
  onDishSelect: (dish: Dish) => void;
}

// Logo "Be Kind" in stile PNG (SVG inline per garantire la visualizzazione senza file esterni)
// Colore: #C6957C (Terra Cotta), Font: Bubble/Rounded
const LOGO_COLOR_URI = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 240 80'%3E%3Cstyle%3E@import url('https://fonts.googleapis.com/css2?family=Fredoka:wght@600');%3C/style%3E%3Ctext x='50%25' y='55%25' dominant-baseline='middle' text-anchor='middle' font-family='Fredoka, sans-serif' font-weight='600' font-size='50' fill='%23C6957C' letter-spacing='2'%3EBE KIND%3C/text%3E%3C/svg%3E";

export const Home: React.FC<HomeProps> = ({ onNavigate, onDishSelect }) => {
  const [animateLogo, setAnimateLogo] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  useEffect(() => {
    setAnimateLogo(true);
  }, []);
  
  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans overflow-hidden relative">
      
      {/* Profile Menu Dropdown */}
      <ProfileMenu isOpen={isProfileOpen} onClose={() => setIsProfileOpen(false)} />

      {/* Animated Header */}
      <div className="px-6 pt-12 pb-6 flex justify-between items-center bg-bekind-bg sticky top-0 z-20">
        <div className={`transition-all duration-1000 ease-out transform origin-left ${animateLogo ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-4 opacity-0 scale-95'}`}>
            {/* Logo Image */}
            <img src={LOGO_COLOR_URI} alt="Be Kind Logo" className="h-14 w-auto object-contain" />
        </div>
        <div className="flex gap-3">
             <button className="w-10 h-10 rounded-full bg-white text-bekind-primary shadow-soft flex items-center justify-center hover:bg-bekind-lightAccent hover:text-white transition-all active:scale-95">
                <Bell size={20} />
            </button>
            <button 
                onClick={() => setIsProfileOpen(!isProfileOpen)}
                className="w-10 h-10 rounded-full overflow-hidden border-2 border-white shadow-soft transition-transform active:scale-95 relative"
            >
                <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?fit=crop&w=100&h=100" alt="Profile" className="w-full h-full object-cover" />
                {isProfileOpen && <div className="absolute inset-0 bg-black/10"></div>}
            </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-6 pb-24">
        
        {/* Clean Hero Message */}
        <div className="mb-8 mt-2 animate-fade-in">
            <h1 className="font-serif text-3xl text-bekind-primary leading-tight">
                Buongiorno, <br/>
                <span className="font-bold text-bekind-accent">Coltiva la gentilezza.</span>
            </h1>
        </div>

        {/* Hero Card */}
        <div className="relative w-full h-64 rounded-[32px] overflow-hidden shadow-soft cursor-pointer mb-8 group" onClick={() => onNavigate('MENU')}>
            <img 
                src="https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?q=80&w=1000&auto=format&fit=crop" 
                alt="Promo" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#676959]/90 to-transparent flex flex-col justify-end p-6">
                <span className="bg-bekind-accent text-white text-[10px] font-bold px-3 py-1.5 rounded-full w-fit mb-2 shadow-sm tracking-wide uppercase">Menu Primavera</span>
                <h4 className="text-white font-serif font-bold text-2xl mb-1">Nuovi Sapori</h4>
                <div className="flex items-center gap-2 text-white/90 text-sm font-medium group-hover:translate-x-1 transition-transform">
                    <span>Scopri i piatti di stagione</span>
                    <ArrowRight size={16} />
                </div>
            </div>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-4 gap-4 mb-10">
            {[
                { icon: Utensils, label: 'Menu', action: () => onNavigate('MENU') },
                { icon: Calendar, label: 'Prenota', action: () => onNavigate('RESERVATION') },
                { icon: ShoppingBag, label: 'Shop', action: () => onNavigate('SHOP') },
                { icon: Bike, label: 'Delivery', action: () => onNavigate('TRACKING') }
            ].map((item, idx) => (
                <button 
                    key={idx}
                    onClick={item.action}
                    className="flex flex-col items-center gap-2 group"
                >
                    <div className="w-16 h-16 rounded-2xl bg-white shadow-soft flex items-center justify-center text-bekind-primary group-active:scale-90 transition-all border-2 border-transparent group-hover:border-bekind-accent/20 group-hover:text-bekind-accent">
                        <item.icon size={24} strokeWidth={2} />
                    </div>
                    <span className="text-xs font-bold text-bekind-text group-hover:text-bekind-primary transition-colors">{item.label}</span>
                </button>
            ))}
        </div>

        {/* Upcoming Events (Horizontal Scroll) */}
        <div>
            <div className="flex justify-between items-end mb-4">
                <h3 className="font-serif font-bold text-xl text-bekind-primary">Eventi & Workshop</h3>
                <button onClick={() => onNavigate('EVENTS')} className="text-bekind-accent text-xs font-bold hover:underline">Vedi tutti</button>
            </div>
            <div className="flex gap-4 overflow-x-auto no-scrollbar pb-6 -mx-6 px-6">
                {UPCOMING_EVENTS.map(event => (
                    <div key={event.id} className="min-w-[260px] bg-white rounded-3xl overflow-hidden shadow-card border border-gray-50 cursor-pointer group hover:shadow-lg transition-shadow" onClick={() => onNavigate('EVENTS')}>
                        <div className="h-36 overflow-hidden relative">
                            <img src={event.images[0]} alt={event.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                            <div className="absolute top-3 left-3 bg-white/90 backdrop-blur px-2.5 py-1 rounded-lg shadow-sm">
                                <span className="text-[10px] font-bold text-bekind-primary uppercase tracking-wide">{event.category}</span>
                            </div>
                        </div>
                        <div className="p-5">
                            <h4 className="font-serif font-bold text-bekind-text text-lg mb-1 truncate">{event.title}</h4>
                            <p className="text-xs text-bekind-secondary flex items-center gap-1.5 font-medium">
                                <Calendar size={14} className="text-bekind-accent" /> {event.date}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};
