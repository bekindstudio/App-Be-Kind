
import React from 'react';

interface OnboardingProps {
  onStart: () => void;
}

// Logo Bianco per l'Onboarding
const LOGO_WHITE_URI = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 240 80'%3E%3Cstyle%3E@import url('https://fonts.googleapis.com/css2?family=Fredoka:wght@600');%3C/style%3E%3Ctext x='50%25' y='55%25' dominant-baseline='middle' text-anchor='middle' font-family='Fredoka, sans-serif' font-weight='600' font-size='50' fill='%23FFFFFF' letter-spacing='2'%3EBE KIND%3C/text%3E%3C/svg%3E";

export const Onboarding: React.FC<OnboardingProps> = ({ onStart }) => {
  return (
    <div className="relative h-full w-full flex flex-col bg-bekind-bg overflow-hidden font-sans">
      
      {/* Background Image Full */}
      <div className="absolute inset-0 z-0">
        <img 
            src="https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?q=80&w=1000&auto=format&fit=crop" 
            alt="Healthy Food" 
            className="w-full h-full object-cover"
        />
        {/* Overlay with brand colors */}
        <div className="absolute inset-0 bg-gradient-to-t from-bekind-primary/90 via-bekind-primary/40 to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col h-full justify-end pb-12 px-8 text-center items-center">
        
        <div className="mb-6 animate-slide-up">
             <img src={LOGO_WHITE_URI} alt="Be Kind Logo" className="h-24 w-auto drop-shadow-lg" />
        </div>

        <h1 className="text-3xl font-serif font-medium text-white mb-4 leading-tight animate-fade-in delay-100">
          Benvenuto nel mondo <br/> della gentilezza.
        </h1>
        
        <p className="text-white/90 text-sm mb-10 font-sans leading-relaxed max-w-xs mx-auto animate-fade-in delay-200">
          Nutri il tuo corpo, connettiti con la community. 
          Ristorazione, Eventi e Shop in un'unica app.
        </p>

        <button 
          onClick={onStart}
          className="w-full bg-bekind-accent hover:bg-bekind-lightAccent text-white font-bold py-4 rounded-3xl shadow-lg transition-all active:scale-95 animate-fade-in delay-300"
        >
          Inizia
        </button>
      </div>
    </div>
  );
};
