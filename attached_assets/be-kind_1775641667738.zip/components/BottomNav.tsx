
import React from 'react';
import { Home, Utensils, Star, User } from 'lucide-react';
import { ViewState } from '../types';

interface BottomNavProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
  cartCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentView, onNavigate, cartCount }) => {
  if (currentView === 'ONBOARDING' || currentView === 'DISH_DETAILS' || currentView === 'CART') return null;

  const NavItem = ({ icon: Icon, label, isActive, onClick, badge }: { icon: any, label: string, isActive: boolean, onClick: () => void, badge?: number }) => (
    <button 
      className={`flex flex-col items-center gap-1 w-16 transition-all duration-300 ${
          isActive ? 'text-bekind-primary' : 'text-gray-400 hover:text-gray-600'
      }`}
      onClick={onClick}
    >
      <div className="relative">
          <Icon size={24} strokeWidth={isActive ? 2.5 : 2} fill={isActive && label === 'Be Kind' ? 'currentColor' : 'none'} />
          {badge ? (
            <span className="absolute -top-1 -right-1 bg-bekind-accent text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-white">
            {badge}
            </span>
        ) : null}
      </div>
      <span className={`text-[10px] font-bold ${isActive ? 'text-bekind-primary' : 'text-transparent'}`}>
        {label}
      </span>
    </button>
  );

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-3 pb-6 shadow-[0_-5px_20px_rgba(0,0,0,0.03)] z-50 flex justify-between items-end">
      <NavItem 
        icon={Home} 
        label="Home"
        isActive={currentView === 'HOME'} 
        onClick={() => onNavigate('HOME')}
      />
      <NavItem 
        icon={Utensils} 
        label="Menù"
        isActive={currentView === 'MENU'} 
        onClick={() => onNavigate('MENU')} // Would link to full menu view
      />
      <NavItem 
        icon={Star} 
        label="Be Kind"
        isActive={currentView === 'LOYALTY'} 
        onClick={() => onNavigate('LOYALTY')}
      />
      <NavItem 
        icon={User} 
        label="Profilo"
        isActive={false} 
        onClick={() => {}}
      />
    </div>
  );
};
