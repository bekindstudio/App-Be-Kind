
import React from 'react';
import { ChevronLeft, Trash2, Minus, Plus, ShoppingBag } from 'lucide-react';
import { CartItem } from '../types';

interface CartProps {
  cartItems: CartItem[];
  onBack: () => void;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onCheckout: () => void;
}

export const Cart: React.FC<CartProps> = ({ cartItems, onBack, onUpdateQuantity, onRemoveItem, onCheckout }) => {
  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shipping = 2.50;
  const total = subtotal + shipping;

  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans overflow-hidden">
      {/* Header */}
      <div className="px-6 pt-12 pb-6 flex items-center justify-between bg-bekind-bg z-10">
        <button onClick={onBack} className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft border border-gray-100">
            <ChevronLeft size={20} className="text-bekind-text" />
        </button>
        <h2 className="text-xl font-serif font-bold text-bekind-text">Il Tuo Ordine</h2>
        <div className="w-10"></div> 
      </div>

      {/* Cart Items List */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-6 pb-24">
        {cartItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center opacity-50">
            <div className="w-20 h-20 bg-bekind-secondary/20 rounded-full flex items-center justify-center mb-4">
                 <ShoppingBag size={40} className="text-bekind-primary" />
            </div>
            <p className="font-serif font-bold text-xl text-bekind-text">Il carrello è vuoto</p>
            <p className="text-sm text-gray-500 mt-2">Aggiungi qualcosa di buono!</p>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {cartItems.map((item) => (
              <div key={`${item.id}-${item.size}`} className="bg-white p-4 rounded-2xl shadow-soft flex gap-4 items-center">
                <div className="w-20 h-20 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-serif font-bold text-sm text-bekind-text truncate">{item.name}</h3>
                  <p className="text-gray-500 text-xs mb-2">{item.category}</p>
                  <p className="font-bold text-bekind-primary text-sm">€{item.price.toFixed(2)}</p>
                </div>

                <div className="flex flex-col items-end gap-2">
                   <button onClick={() => onRemoveItem(item.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                      <Trash2 size={16} />
                   </button>
                   
                   <div className="flex items-center gap-2 bg-bekind-bg rounded-lg px-2 py-1">
                      <button 
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="w-6 h-6 rounded flex items-center justify-center text-bekind-primary disabled:opacity-50 font-bold"
                        disabled={item.quantity <= 1}
                      >
                        -
                      </button>
                      <span className="text-xs font-bold w-4 text-center text-bekind-text">{item.quantity}</span>
                      <button 
                         onClick={() => onUpdateQuantity(item.id, 1)}
                         className="w-6 h-6 rounded flex items-center justify-center text-bekind-primary font-bold"
                      >
                        +
                      </button>
                   </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer Summary */}
      {cartItems.length > 0 && (
        <div className="bg-white rounded-t-[30px] p-8 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.05)] z-20">
          <div className="space-y-3 mb-6">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Subtotale</span>
              <span className="font-bold text-bekind-text">€{subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Spedizione</span>
              <span className="font-bold text-bekind-text">€{shipping.toFixed(2)}</span>
            </div>
            <div className="h-px bg-gray-100 my-2"></div>
            <div className="flex justify-between text-lg font-serif font-bold">
              <span className="text-bekind-text">Totale</span>
              <span className="text-bekind-primary">€{total.toFixed(2)}</span>
            </div>
          </div>
          
          <button 
            onClick={onCheckout}
            className="w-full bg-bekind-primary text-white font-bold py-4 rounded-2xl shadow-lg hover:scale-[1.02] transition-transform active:scale-95"
          >
            Procedi al Pagamento
          </button>
        </div>
      )}
    </div>
  );
};