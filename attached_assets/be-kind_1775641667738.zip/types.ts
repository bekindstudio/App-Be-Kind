
export interface Dish {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  allergens?: string[];
  isVegetarian?: boolean;
  isVegan?: boolean;
  rating: number;
  reviews: number;
}

export interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  images: string[]; // Changed from image to images array
  price: number;
  category: string;
  description: string;
  totalSpots: number;
  bookedSpots: number;
}

export interface ShopProduct {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  description: string;
}

export type ViewState = 'ONBOARDING' | 'HOME' | 'MENU' | 'DISH_DETAILS' | 'CART' | 'CHECKOUT' | 'EVENTS' | 'EVENT_DETAILS' | 'RESERVATION' | 'SHOP' | 'TRACKING' | 'LOYALTY';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  quantity: number;
  notes?: string;
  size?: string;
  attendees?: { name: string; surname: string }[]; // New: for event tickets
}

export interface LoyaltyReward {
  id: string;
  title: string;
  cost: number;
  image: string;
  type: 'FOOD' | 'MERCH' | 'EXPERIENCE';
  description: string;
}

export interface LoyaltyAction {
  id: string;
  title: string;
  points: number;
  stamps: number;
  icon: string;
  description: string;
}

export interface LoyaltyStamp {
  id: string;
  title: string;
  icon: string;
  description: string;
  actionRequired: string;
}

export interface UserLoyaltyState {
  level: 'Seme' | 'Germoglio' | 'Quercia';
  points: number;
  earnedStamps: string[];
  history: {
    date: string;
    action: string;
    points: number;
  }[];
}
