
import React, { useState } from 'react';
import { ChevronLeft, ShoppingBag, Plus, Filter } from 'lucide-react';
import { SHOP_PRODUCTS, SHOP_CATEGORIES } from '../constants';
import { ShopProduct } from '../types';

interface ShopProps {
  onBack: () => void;
  onAddToCart: (product: ShopProduct) => void;
}

export const Shop: React.FC<ShopProps> = ({ onBack, onAddToCart }) => {
  const [activeCategory, setActiveCategory] = useState('Tutti');

  const filteredProducts = SHOP_PRODUCTS.filter(p => 
    activeCategory === 'Tutti' || p.category === activeCategory
  );

  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans">
       <div className="px-6 pt-12 pb-4 flex items-center justify-between bg-bekind-bg sticky top-0 z-10">
        <button onClick={onBack} className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft text-bekind-primary hover:bg-bekind-secondary/10 transition-colors active:scale-95">
            <ChevronLeft size={24} />
        </button>
        <h2 className="text-xl font-serif font-bold text-bekind-primary">Be Kind Shop</h2>
        <button className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft text-bekind-primary active:scale-95 transition-transform">
            <ShoppingBag size={20} />
        </button>
      </div>

      {/* Categories Filter */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar px-6 pb-6 pt-2">
        {SHOP_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-full whitespace-nowrap text-xs font-bold transition-all border active:scale-95 ${
              activeCategory === cat 
                ? 'bg-bekind-primary text-white border-bekind-primary shadow-lg' 
                : 'bg-white/50 text-bekind-primary border-bekind-primary/20 hover:border-bekind-primary/50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24 no-scrollbar">
        {/* Hero Banner only shows on 'Tutti' */}
        {activeCategory === 'Tutti' && (
            <div className="bg-[#676959] rounded-3xl p-6 text-white mb-8 relative overflow-hidden shadow-soft group cursor-pointer active:scale-[0.98] transition-all">
                <div className="relative z-10">
                    <span className="bg-bekind-accent text-[10px] font-bold px-2 py-1 rounded mb-2 inline-block shadow-sm">New In</span>
                    <h3 className="font-serif font-bold text-2xl mb-2">Merch Sostenibile</h3>
                    <p className="text-white/80 text-sm mb-4 max-w-[70%]">Cotone organico e materiali riciclati per il pianeta.</p>
                </div>
                <img 
                    src="https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&q=80&w=600" 
                    className="absolute right-0 top-0 h-full w-1/2 object-cover opacity-20 mask-image-gradient"
                    alt="Sustainable"
                />
            </div>
        )}

        <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg text-bekind-primary">
                {activeCategory === 'Tutti' ? 'In Evidenza' : activeCategory}
            </h3>
            <span className="text-xs text-bekind-secondary">{filteredProducts.length} prodotti</span>
        </div>

        <div className="grid grid-cols-2 gap-4">
            {filteredProducts.map(product => (
                <div key={product.id} className="bg-white p-3 rounded-2xl shadow-card flex flex-col group transition-transform hover:-translate-y-1 hover:shadow-lg cursor-pointer">
                    <div className="h-36 bg-gray-50 rounded-xl overflow-hidden mb-3 relative">
                        <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                        <button 
                            onClick={(e) => {
                                e.stopPropagation();
                                onAddToCart(product);
                            }}
                            className="absolute bottom-2 right-2 w-8 h-8 bg-white rounded-full flex items-center justify-center text-bekind-primary shadow-md active:scale-90 transition-transform hover:bg-bekind-accent hover:text-white"
                        >
                            <Plus size={16} />
                        </button>
                    </div>
                    <div className="flex-1 flex flex-col">
                        <span className="text-[10px] text-bekind-accent font-bold uppercase tracking-wider mb-1">{product.category}</span>
                        <h4 className="font-serif font-bold text-bekind-text text-sm mb-1 leading-tight line-clamp-2">{product.name}</h4>
                        <div className="mt-auto pt-2">
                             <span className="text-bekind-primary font-bold">€{product.price.toFixed(2)}</span>
                        </div>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};
