
import React, { useState } from 'react';
import { ChevronLeft, Calendar, Clock, MapPin, Users, Share2, Info, ShoppingCart } from 'lucide-react';
import { Event } from '../types';

interface EventDetailsProps {
  event: Event;
  onBack: () => void;
  onBook: (event: Event, quantity: number) => void;
}

export const EventDetails: React.FC<EventDetailsProps> = ({ event, onBack, onBook }) => {
  const [ticketQuantity, setTicketQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const spotsLeft = event.totalSpots - event.bookedSpots;
  const progressPercentage = (event.bookedSpots / event.totalSpots) * 100;

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const scrollPosition = e.currentTarget.scrollLeft;
    const width = e.currentTarget.offsetWidth;
    const index = Math.round(scrollPosition / width);
    setCurrentImageIndex(index);
  };

  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans relative">
      
      {/* Top Nav (Absolute) */}
      <div className="absolute top-0 left-0 right-0 z-30 px-6 pt-12 flex justify-between items-center pointer-events-none">
        <button onClick={onBack} className="pointer-events-auto w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center shadow-soft text-bekind-primary hover:bg-white transition-colors">
            <ChevronLeft size={24} />
        </button>
        <button className="pointer-events-auto w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center shadow-soft text-bekind-primary hover:bg-white transition-colors">
            <Share2 size={20} />
        </button>
      </div>

      {/* Main Scrollable Area */}
      <div className="flex-1 overflow-y-auto no-scrollbar pb-32">
        
        {/* Image Slider */}
        <div className="h-[350px] w-full relative group">
           <div 
             className="w-full h-full flex overflow-x-auto snap-x snap-mandatory no-scrollbar"
             onScroll={handleScroll}
           >
             {event.images.map((img, idx) => (
               <img 
                  key={idx}
                  src={img} 
                  alt={`${event.title} - ${idx + 1}`} 
                  className="w-full h-full object-cover flex-shrink-0 snap-center"
               />
             ))}
           </div>
           
           {/* Slider Dots */}
           <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-2">
             {event.images.map((_, idx) => (
               <div 
                 key={idx}
                 className={`w-2 h-2 rounded-full transition-all shadow-sm ${
                   currentImageIndex === idx ? 'bg-white w-4' : 'bg-white/50'
                 }`}
               />
             ))}
           </div>
           
           <div className="absolute inset-0 bg-gradient-to-t from-bekind-bg via-transparent to-black/10 pointer-events-none"></div>
           
           <div className="absolute bottom-12 left-6">
               <span className="bg-bekind-accent text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider shadow-sm mb-2 inline-block backdrop-blur-sm">{event.category}</span>
           </div>
        </div>

        {/* Content */}
        <div className="px-6 -mt-6 relative z-10">
            
            {/* Title & Price */}
            <div className="flex justify-between items-start mb-6">
                <h1 className="font-serif font-bold text-3xl text-bekind-text leading-tight max-w-[70%] drop-shadow-sm">{event.title}</h1>
                <div className="text-right bg-white/50 px-3 py-2 rounded-xl backdrop-blur-sm">
                    <span className="block font-bold text-2xl text-bekind-primary">€{event.price.toFixed(2)}</span>
                    <span className="text-xs text-gray-500">a persona</span>
                </div>
            </div>

            {/* Info Grid */}
            <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-white p-3 rounded-2xl shadow-sm border border-bekind-secondary/10 flex items-center gap-3">
                    <div className="bg-[#FFFBF5] p-2.5 rounded-xl text-bekind-accent">
                        <Calendar size={18} />
                    </div>
                    <div>
                        <p className="text-[10px] text-gray-400 font-bold uppercase">Data</p>
                        <p className="text-sm font-bold text-bekind-text">{event.date.split('2024')[0]}</p>
                    </div>
                </div>
                <div className="bg-white p-3 rounded-2xl shadow-sm border border-bekind-secondary/10 flex items-center gap-3">
                    <div className="bg-[#FFFBF5] p-2.5 rounded-xl text-bekind-accent">
                        <Clock size={18} />
                    </div>
                    <div>
                        <p className="text-[10px] text-gray-400 font-bold uppercase">Orario</p>
                        <p className="text-sm font-bold text-bekind-text">{event.time}</p>
                    </div>
                </div>
            </div>

            <div className="bg-white p-3 rounded-2xl shadow-sm border border-bekind-secondary/10 flex items-center gap-3 mb-6">
                <div className="bg-[#FFFBF5] p-2.5 rounded-xl text-bekind-accent">
                    <MapPin size={18} />
                </div>
                <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">Luogo</p>
                    <p className="text-sm font-bold text-bekind-text">{event.location}</p>
                </div>
            </div>

            {/* Availability Bar */}
            <div className="mb-8 bg-white p-4 rounded-2xl shadow-sm">
                <div className="flex justify-between items-end mb-2">
                    <div className="flex items-center gap-2 text-bekind-primary font-bold text-sm">
                        <Users size={16} />
                        <span>Disponibilità</span>
                    </div>
                    <span className="text-xs font-bold text-bekind-accent">{spotsLeft} posti rimasti</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                    <div 
                        className="h-full bg-bekind-accent rounded-full transition-all duration-1000" 
                        style={{ width: `${progressPercentage}%` }}
                    ></div>
                </div>
            </div>

            {/* Description */}
            <div className="mb-4">
                <div className="flex items-center gap-2 mb-3">
                    <Info size={18} className="text-bekind-primary" />
                    <h3 className="font-bold text-bekind-text text-lg">Dettagli Evento</h3>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed whitespace-pre-line font-medium">
                    {event.description}
                </p>
            </div>
            
        </div>
      </div>

      {/* Sticky Bottom Action Bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-4 pb-8 z-30 shadow-[0_-5px_30px_rgba(0,0,0,0.08)]">
        <div className="flex items-center gap-4 w-full">
             {/* Ticket Quantity Stepper */}
             <div className="flex items-center justify-between bg-bekind-bg rounded-2xl px-4 py-3 min-w-[120px]">
                 <button 
                    onClick={() => ticketQuantity > 1 && setTicketQuantity(q => q - 1)} 
                    className="text-bekind-primary font-bold text-xl active:scale-90 transition-transform w-8 h-8 flex items-center justify-center rounded-full bg-white shadow-sm"
                 >
                    -
                 </button>
                 <span className="text-bekind-text font-bold text-lg">{ticketQuantity}</span>
                 <button 
                    onClick={() => ticketQuantity < spotsLeft && setTicketQuantity(q => q + 1)} 
                    className="text-bekind-primary font-bold text-xl active:scale-90 transition-transform w-8 h-8 flex items-center justify-center rounded-full bg-white shadow-sm"
                 >
                    +
                 </button>
             </div>

            {/* Add to Cart Button */}
            <button 
                onClick={() => onBook(event, ticketQuantity)}
                className="flex-1 bg-bekind-primary text-white font-bold py-4 rounded-2xl shadow-lg hover:bg-opacity-90 transition-all flex items-center justify-center gap-3 active:scale-[0.98]"
            >
                <div className="flex flex-col items-start leading-none">
                    <span className="text-[10px] uppercase opacity-80 font-medium">Totale</span>
                    <span className="text-base">€{(event.price * ticketQuantity).toFixed(2)}</span>
                </div>
                <div className="h-8 w-px bg-white/20 mx-1"></div>
                <div className="flex items-center gap-2">
                    <span>Aggiungi</span>
                    <ShoppingCart size={20} fill="currentColor" />
                </div>
            </button>
        </div>
      </div>
    </div>
  );
};
