import React, { useState } from 'react';
import { ChevronLeft, Calendar, Clock, Users, Check, User, Mail, Phone } from 'lucide-react';

interface ReservationProps {
  onBack: () => void;
}

export const Reservation: React.FC<ReservationProps> = ({ onBack }) => {
  const [guests, setGuests] = useState(2);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  
  // Stati per i dati personali
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: ''
  });

  const timeSlots = ['19:00', '19:30', '20:00', '20:30', '21:00', '21:30'];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Validazione semplice: tutti i campi devono essere compilati e un orario selezionato
  const isFormValid = selectedTime && formData.firstName && formData.lastName && formData.email && formData.phone;

  if (confirmed) {
    return (
        <div className="flex flex-col h-full bg-bekind-bg items-center justify-center px-8 text-center font-sans">
            <div className="w-24 h-24 bg-[#E9F5E9] rounded-full flex items-center justify-center mb-6 shadow-soft animate-bounce">
                <Check size={40} className="text-bekind-primary" />
            </div>
            <h2 className="text-3xl font-serif font-bold text-bekind-text mb-2">Prenotazione Confermata!</h2>
            <p className="text-gray-600 mb-8 max-w-[250px] mx-auto leading-relaxed">
                Grazie <span className="font-bold text-bekind-primary">{formData.firstName}</span>, ti aspettiamo il 15 Marzo alle {selectedTime} per {guests} persone.
            </p>
            <div className="w-full bg-white p-4 rounded-2xl shadow-soft mb-8 text-left">
                <p className="text-xs text-gray-400 uppercase font-bold mb-2">Riepilogo</p>
                <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Tavolo per</span>
                    <span className="font-bold text-bekind-text">{guests} Ospiti</span>
                </div>
                <div className="flex justify-between text-sm">
                     <span className="text-gray-600">Contatto</span>
                     <span className="font-bold text-bekind-text">{formData.phone}</span>
                </div>
            </div>
            <button onClick={onBack} className="w-full bg-bekind-primary text-white font-bold py-4 px-8 rounded-2xl shadow-lg hover:bg-opacity-90 transition-all">
                Torna alla Home
            </button>
        </div>
    )
  }

  return (
    <div className="flex flex-col h-full bg-bekind-bg font-sans">
      <div className="px-6 pt-12 pb-6 flex items-center gap-4 bg-bekind-bg sticky top-0 z-10">
        <button onClick={onBack} className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-soft text-bekind-primary border border-gray-50">
            <ChevronLeft size={24} />
        </button>
        <h2 className="text-xl font-serif font-bold text-bekind-text">Prenota Tavolo</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-32 no-scrollbar">
        
        {/* Step 1: Data e Ospiti */}
        <div className="bg-white p-6 rounded-3xl shadow-soft mb-4">
             {/* Calendar Header */}
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2 text-bekind-primary">
                    <Calendar size={20} />
                    <span className="font-bold text-lg">Marzo 2024</span>
                </div>
                <div className="flex items-center gap-2 bg-bekind-bg px-3 py-1 rounded-full">
                    <Users size={16} className="text-bekind-accent" />
                    <span className="font-bold text-bekind-text">{guests} Ospiti</span>
                    <div className="flex gap-1 ml-2">
                        <button onClick={() => setGuests(Math.max(1, guests - 1))} className="w-6 h-6 bg-white rounded-full shadow-sm text-bekind-primary font-bold flex items-center justify-center">-</button>
                        <button onClick={() => setGuests(Math.min(10, guests + 1))} className="w-6 h-6 bg-white rounded-full shadow-sm text-bekind-primary font-bold flex items-center justify-center">+</button>
                    </div>
                </div>
            </div>

            {/* Simple static calendar strip */}
            <div className="flex justify-between text-center mb-2">
                 {['L', 'M', 'M', 'G', 'V', 'S', 'D'].map((d, i) => (
                     <span key={i} className="text-xs text-gray-400 font-bold w-8">{d}</span>
                 ))}
            </div>
            <div className="flex justify-between text-center">
                {['10', '11', '12', '13', '14', '15', '16'].map((day, i) => (
                    <button 
                        key={i}
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                            day === '15' 
                            ? 'bg-bekind-accent text-white shadow-md scale-110' 
                            : 'text-bekind-text hover:bg-gray-100'
                        }`}
                    >
                        {day}
                    </button>
                ))}
            </div>
        </div>

        {/* Step 2: Orario */}
        <div className="bg-white p-6 rounded-3xl shadow-soft mb-4">
             <div className="flex items-center gap-2 mb-4 text-bekind-primary">
                <Clock size={20} />
                <span className="font-bold text-lg">Orario</span>
            </div>
            <div className="grid grid-cols-3 gap-3">
                {timeSlots.map(time => (
                    <button 
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`py-3 rounded-xl text-sm font-bold transition-all border ${
                            selectedTime === time 
                            ? 'bg-bekind-primary border-bekind-primary text-white shadow-md' 
                            : 'bg-white border-gray-100 text-gray-500 hover:border-bekind-secondary'
                        }`}
                    >
                        {time}
                    </button>
                ))}
            </div>
        </div>

        {/* Step 3: Dati Personali */}
        <div className="bg-white p-6 rounded-3xl shadow-soft mb-6">
            <div className="flex items-center gap-2 mb-6 text-bekind-primary">
                <User size={20} />
                <span className="font-bold text-lg">I tuoi dati</span>
            </div>
            
            <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                        <label className="text-xs font-bold text-gray-500 ml-1">Nome</label>
                        <input 
                            type="text" 
                            name="firstName"
                            value={formData.firstName}
                            onChange={handleInputChange}
                            placeholder="Mario"
                            className="w-full bg-[#F9F9F9] border border-transparent focus:border-bekind-accent focus:bg-white rounded-xl py-3 px-4 text-sm outline-none transition-all placeholder:text-gray-300 text-bekind-text font-medium"
                        />
                    </div>
                    <div className="space-y-1">
                        <label className="text-xs font-bold text-gray-500 ml-1">Cognome</label>
                         <input 
                            type="text" 
                            name="lastName"
                            value={formData.lastName}
                            onChange={handleInputChange}
                            placeholder="Rossi"
                            className="w-full bg-[#F9F9F9] border border-transparent focus:border-bekind-accent focus:bg-white rounded-xl py-3 px-4 text-sm outline-none transition-all placeholder:text-gray-300 text-bekind-text font-medium"
                        />
                    </div>
                </div>

                <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 ml-1">Email</label>
                    <div className="relative">
                        <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input 
                            type="email" 
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            placeholder="mario.rossi@email.com"
                            className="w-full bg-[#F9F9F9] border border-transparent focus:border-bekind-accent focus:bg-white rounded-xl py-3 pl-10 pr-4 text-sm outline-none transition-all placeholder:text-gray-300 text-bekind-text font-medium"
                        />
                    </div>
                </div>

                <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 ml-1">Telefono</label>
                    <div className="relative">
                        <Phone size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input 
                            type="tel" 
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            placeholder="+39 333 1234567"
                            className="w-full bg-[#F9F9F9] border border-transparent focus:border-bekind-accent focus:bg-white rounded-xl py-3 pl-10 pr-4 text-sm outline-none transition-all placeholder:text-gray-300 text-bekind-text font-medium"
                        />
                    </div>
                </div>
            </div>
        </div>

      </div>

      {/* Floating Action Button */}
      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-bekind-bg via-bekind-bg to-transparent pointer-events-none">
        <button 
            disabled={!isFormValid}
            onClick={() => setConfirmed(true)}
            className="w-full bg-bekind-accent disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl shadow-lg transition-transform active:scale-95 pointer-events-auto flex items-center justify-center gap-2"
        >
            <span>Conferma Prenotazione</span>
            {isFormValid && <Check size={18} />}
        </button>
      </div>
    </div>
  );
};